﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TicTacToC
{
    public partial class Game : System.Web.UI.Page
    {
        Table GameBoard = new Table();
        int bordSize;
        protected void Page_PreInit(object sender, EventArgs e)
        {
            ViewState["turn"] = true;
            bordSize = int.Parse(Request.QueryString["BordSize"]);
            GameBoard.ID = "GameBoard";

        }
        protected void Page_Load(object sender, EventArgs e)
        {
            CreateTable(bordSize);
        }

        protected bool RowCheck(string td)
        {
            bool turn = (bool)ViewState["turn"];
            bool win= true;
            int column = int.Parse(td[0].ToString());
            int row = int.Parse(td[1].ToString());
            string imgButton = td[0].ToString() + td[1].ToString() + td[0].ToString() + td[1].ToString();
            for (int i=0;i<bordSize;i++)
            {

                ImageButton bu2 = (ImageButton)GameBoard.Rows[row].Cells[i].FindControl(imgButton);
                string url = bu2.ImageUrl;
                if (turn == true)
                {
                    if(url != "Xsymbol.png")
                    {
                        win = false;
                    }
                }
                else if(turn == false)
                {
                    if(url != "CirSymbol.png")
                    {
                        win = false;
                    }
                }
            }
            return win;
        }
        protected void ImageButton_Click(object sender, ImageClickEventArgs e)
        {
            ImageButton pressed = (ImageButton)sender;
            string td = pressed.Parent.ID;
            string pressIden = pressed.ImageUrl;
            bool turn = (bool)ViewState["turn"];
            if (pressIden == "empty.png")
            {
                if ((bool)ViewState["turn"] == true)
                {
                    ImageButton button = (ImageButton)sender;
                    button.ImageUrl = "Xsymbol.png";
                    turn = false;
                }
                else if ((bool)ViewState["turn"] == false)
                {
                    ImageButton button = (ImageButton)sender;
                    button.ImageUrl = "CirSymbol.png";
                    turn = true;
                }
                ViewState["turn"] = turn;
                bool win = RowCheck(td);
            }
            
        }

        protected void CreateTable(int rows)
        {
            for (int i = 0; i < rows; i++)
            {
                TableRow row = new TableRow();
                for (int j = 0; j < rows; j++)
                {
                    TableCell cell = new TableCell();
                    cell.ID = ""+j+""+""+i+"";
                    ImageButton imagebutton = new ImageButton();
                    imagebutton.ID = "" + j + "" + "" + i + "" +j+ "" +i+"";
                    imagebutton.CssClass = "GameSym";
                    imagebutton.Click += new ImageClickEventHandler(ImageButton_Click);
                    imagebutton.ImageUrl = "empty.png";
                    cell.Controls.Add(imagebutton);
                    row.Cells.Add(cell);
                }
                GameBoard.Rows.Add(row);
            }
            form1.Controls.Add(GameBoard);
        }
    }
}