﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TicTacToC
{
    public partial class OpeningPage : System.Web.UI.Page
    {
        private HttpCookie PLAYERX;
        private HttpCookie PLAYERY;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (PLAYERX != null && PLAYERY != null)
            {
                TextBox3.Text = PLAYERY.Value;
                TextBox2.Text = PLAYERX.Value;
            }



        }



        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            if (TextBox2.Text == "" && TextBox3.Text == "")//X left size
            {
                massage1.Text = "write player X and player O name";
                TextBox2.Focus();
            }
            else if (TextBox2.Text == "")
            {
                massage1.Text = "write player X name";
                TextBox2.Focus();
            }
            else if (TextBox3.Text == "")
            {
                massage1.Text = "write player O name";
                TextBox3.Focus();
            }
            else if (RadioButtonList1.SelectedValue == "")
            {
                massage2.Text = "please chose a bord size";
            }
            //   COOKIES
            else
            {
                HttpCookie PLAYERX = new HttpCookie(TextBox2.Text);
                HttpCookie PLAYERO = new HttpCookie(TextBox3.Text);
                Response.Cookies.Add(PLAYERO);
                Response.Cookies.Add(PLAYERX);

                Response.Redirect("Game.aspx?BordSize=" + RadioButtonList1.SelectedValue);
            }

        }


    }
}